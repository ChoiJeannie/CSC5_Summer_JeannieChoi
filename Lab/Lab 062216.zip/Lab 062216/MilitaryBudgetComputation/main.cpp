/* 
 * File:   main.cpp
 * Author: Jeannie Choi
 * Created on June 21, 2016, 1:33 PM
 * Purpose: First Program
 */

//System Libraries
#include <iostream> //Input/Output Stream Library
using namespace std;//Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables, no doubles
    float milBudget;// military budget
    float fedBudget;// federal budget
    float percent;// percentage of federal budget spent on military
    
    milBudget = 0.6e12
    fedBudget = 3.8e12

    //Input data
    
    //Process data
    percent = milBudget/fedBudget*100.0        
    cout <<"The percent of federal budget spent on military is "<< percent <<endl;
            
    //Output data
  
    //Exit Stage Right!
    return 0;
}


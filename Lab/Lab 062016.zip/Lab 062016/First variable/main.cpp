/* 
 * File:   main.cpp
 * Author: Jeannie Choi
 * Created on June 20, 2016, 12:45 PM
 * Purpose: First Program
 */

//System Libraries
#include <iostream> //Input/Output Stream Library
using namespace std;//iostream uses the standard namespace

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables, no doubles
    
    //Input data
    
    //Process data
    
    //Output data
    Cout<<"Hello World"<<endl;
    
    //Exit Stage Rigjt!

    return 0;
}

